import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import re

# Set page config
st.set_page_config(page_title=" Language Detector", page_icon="📝")

def clean_text(text):
    text = text.lower()
    # Keep all Unicode letters and numbers, only remove special punctuation
    # This preserves language-specific characters like accents
    text = re.sub(r'[^\w\s]', ' ', text, flags=re.UNICODE)  # Replace punctuation with space
    text = re.sub(r'\d+', '', text)      # Remove numbers
    text = ' '.join(text.split())         # Remove extra whitespace
    return text

@st.cache_resource
def train_model(data):
    # Basic Preprocessing
    X = data["Text"].apply(clean_text)
    y = data["Language"]
    
    # Split data for better evaluation (optional, but good practice)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Vectorization (using TF-IDF with bigrams and character-level n-grams for better accuracy)
    cv = TfidfVectorizer(ngram_range=(1, 3), max_features=5000, analyzer='char_wb')
    X_train_cv = cv.fit_transform(X_train)
    
    # Train Model with class weights to handle imbalance
    model = MultinomialNB(alpha=0.1)
    model.fit(X_train_cv, y_train)
    
    # Optional: Evaluate on test set
    X_test_cv = cv.transform(X_test)
    accuracy = model.score(X_test_cv, y_test)
    st.write(f"Model Accuracy on Test Set: {accuracy:.2f}")
    
    return cv, model

# Load Data
try:
    df = pd.read_csv('Language Detection.csv')
    cv, model = train_model(df)
    
    st.title("📝 Dynamic Language Detector")
    st.markdown("Type any sentence below, and the AI will detect the language based on your dataset.")

    # User Input Section
    user_text = st.text_area("Enter text here:", placeholder="e.g., Nature is beautiful or C'est la vie")

    if user_text:
        # Transform the user input (clean it first)
        cleaned_input = clean_text(user_text)
        data_input = cv.transform([cleaned_input]).toarray()
        # Predict
        prediction = model.predict(data_input)
        prediction_proba = model.predict_proba(data_input)
        
        # Get confidence score
        confidence = max(prediction_proba[0])
        
        # Display Result
        st.success(f"The detected language is: **{prediction[0]}**")
        st.info(f"Confidence: {confidence:.1%}")
        
        # Add some flair
        if prediction[0] == "English": st.write("🇬🇧 / 🇺🇸")
        elif prediction[0] == "French": st.write("🇫🇷")
        elif prediction[0] == "Spanish": st.write("🇪🇸")
        elif prediction[0] == "Hindi": st.write("🇮🇳")
        elif prediction[0] == "Telugu": st.write("🇮🇳 (Telugu)")
        elif prediction[0] == "Kannada": st.write("🇮🇳 (Kannada)")
        elif prediction[0] == "Malayalam": st.write("🇮🇳 (Malayalam)")
        elif prediction[0] == "Tamil": st.write("🇮🇳 (Tamil)")
        elif prediction[0] == "German": st.write("🇩🇪")
        elif prediction[0] == "Italian": st.write("🇮🇹")
        elif prediction[0] == "Russian": st.write("🇷🇺")
        elif prediction[0] == "Dutch": st.write("🇳🇱")
        elif prediction[0] == "Portuguese": st.write("🇧🇷 / 🇵🇹")
        elif prediction[0] == "Portugeese": st.write("🇧🇷 / 🇵🇹")
        elif prediction[0] == "Greek": st.write("🇬🇷")
        elif prediction[0] == "Turkish": st.write("🇹🇷")
        elif prediction[0] == "Arabic": st.write("🇸🇦")
        elif prediction[0] == "Danish": st.write("🇩🇰")
        elif prediction[0] == "Swedish": st.write("🇸🇪")
        elif prediction[0] == "Sweedish": st.write("🇸🇪")

    # Show Dataset for reference
    with st.expander("View Training Data"):
        st.dataframe(df.sample(10))

except FileNotFoundError:
    st.error("Please ensure 'Language Detection.csv' is in the same folder as this script.")